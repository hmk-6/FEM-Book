function dm
% ========================================================================
% 总体刚度矩阵程序设计作业（二维杆系/桁架）
% 姓名：韩梦坤   学号：20252110045
% MATLAB版本：R2024a（无需额外工具箱）
%
% 功能：
% 1. 根据节点坐标和单元连接关系自动生成对号矩阵 LM；
% 2. 计算二维桁架单元刚度矩阵并直接组装总体刚度矩阵 K；
% 3. 采用缩减法处理位移边界条件；
% 4. 求解节点位移、约束反力、单元应变、应力和轴力；
% 5. 自动完成两个验证算例，并将结果保存为文本文件。
% ========================================================================
clc; clear;

%% 算例一：一维两单元杆（用二维桁架单元退化实现）
case1.title = '算例一：一维两单元杆（二维桁架退化模型）';
case1.x = [0; 1; 2];
case1.y = [0; 0; 0];
case1.IEN = [1 2; 2 3];
case1.E = [100; 200];
case1.A = [1; 1];
case1.fixed_dof = [1 2 4 6];
case1.fixed_val = [0 0 0 0];
case1.force_dof = [5 6];
case1.force_val = [10 0];
run_case(case1, '算例一结果.txt');

%% 算例二：二维两杆桁架
case2.title = '算例二：二维两杆桁架';
case2.x = [1; 0; 1];
case2.y = [0; 0; 1];
case2.IEN = [1 3; 2 3];
case2.E = [1; 1];
case2.A = [1; 1];
case2.fixed_dof = [1 2 3 4];
case2.fixed_val = [0 0 0 0];
case2.force_dof = [5 6];
case2.force_val = [10 0];
run_case(case2, '算例二结果.txt');

fprintf('\n两个算例均已计算完成，结果文本已保存在当前文件夹。\n');
end

function run_case(data, output_file)
% 对单个二维桁架算例执行前处理、组装、求解和后处理

fid = fopen(output_file, 'w', 'n', 'UTF-8');
if fid == -1
    error('无法创建输出文件：%s', output_file);
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

nsd = 2; %#ok<NASGU> % 空间维数
ndof = 2;             % 每节点自由度数
nen = 2;              % 每单元节点数
nnp = length(data.x); % 节点数
nel = size(data.IEN,1); % 单元数
n_global_dof = nnp * ndof;

print_both(fid, '========== %s ==========\n', data.title);
print_both(fid, '节点数: %d, 单元数: %d, 总自由度数: %d\n', ...
    nnp, nel, n_global_dof);
print_both(fid, '固定自由度: %s\n', mat2str(data.fixed_dof));
print_both(fid, '载荷自由度: %s\n', mat2str(data.force_dof));
print_both(fid, '==========================================\n\n');

%% 1. 自动生成对号矩阵 LM
LM = zeros(ndof*nen, nel);
for e = 1:nel
    nodes = data.IEN(e,:);
    for a = 1:nen
        for i = 1:ndof
            row = (a-1)*ndof + i;
            LM(row,e) = (nodes(a)-1)*ndof + i;
        end
    end
end
print_both(fid, '对号矩阵 LM (每列对应一个单元的总体自由度编号):\n');
print_matrix(fid, LM, '%8d');

%% 2. 直接组装总体刚度矩阵
K = zeros(n_global_dof, n_global_dof);
elem_info = zeros(nel,3); % L, c, s
for e = 1:nel
    n1 = data.IEN(e,1); n2 = data.IEN(e,2);
    dx = data.x(n2)-data.x(n1);
    dy = data.y(n2)-data.y(n1);
    L = sqrt(dx^2+dy^2);
    if L <= eps
        error('单元 %d 的长度为零，请检查节点坐标。', e);
    end
    c = dx/L; s = dy/L;
    elem_info(e,:) = [L,c,s];
    ke = data.E(e)*data.A(e)/L * ...
        [ c^2, c*s, -c^2, -c*s;
          c*s, s^2, -c*s, -s^2;
         -c^2,-c*s,  c^2,  c*s;
         -c*s,-s^2,  c*s,  s^2 ];
    for a = 1:ndof*nen
        for b = 1:ndof*nen
            I = LM(a,e); J = LM(b,e);
            K(I,J) = K(I,J) + ke(a,b);
        end
    end
end

print_both(fid, '\n总体刚度矩阵 K (%dx%d):\n', n_global_dof, n_global_dof);
print_matrix(fid, K, '%12.4f');
err_sym = max(max(abs(K-K.')));
print_both(fid, '\n对称性检查（最大不对称量）: %.6e\n', err_sym);
if rank(K) < n_global_dof
    print_both(fid, '施加边界条件前总体刚度矩阵奇异（秩亏），符合预期。\n\n');
end

%% 3. 缩减法处理边界条件并求解
all_dof = 1:n_global_dof;
free_dof = setdiff(all_dof, data.fixed_dof);
K_FF = K(free_dof,free_dof);
K_FE = K(free_dof,data.fixed_dof);
K_EF = K(data.fixed_dof,free_dof);
K_EE = K(data.fixed_dof,data.fixed_dof);

F = zeros(n_global_dof,1);
F(data.force_dof) = data.force_val(:);
F_F = F(free_dof);
F_E = F(data.fixed_dof);
d_E = data.fixed_val(:);

if rcond(K_FF) < 1.0e-12
    error('缩减刚度矩阵 K_FF 奇异或病态，请检查约束与结构稳定性。');
end
d_F = K_FF \ (F_F-K_FE*d_E);

d = zeros(n_global_dof,1);
d(free_dof) = d_F;
d(data.fixed_dof) = d_E;
r_E = K_EF*d_F + K_EE*d_E - F_E;

print_both(fid, '========== 求解结果 ==========\n');
print_both(fid, '节点位移（全局自由度顺序）:\n');
for i = 1:n_global_dof
    print_both(fid, 'd_%d = %12.6f\n', i, d(i));
end
print_both(fid, '\n约束反力（固定自由度上的力）:\n');
for i = 1:length(data.fixed_dof)
    print_both(fid, 'r_%d = %12.6f\n', data.fixed_dof(i), r_E(i));
end
print_both(fid, '\n缩减后刚度矩阵 K_FF 非奇异，求解成功。\n');

%% 4. 单元后处理
print_both(fid, '\n========== 单元结果 ==========\n');
for e = 1:nel
    n1 = data.IEN(e,1); n2 = data.IEN(e,2);
    L = elem_info(e,1); c = elem_info(e,2); s = elem_info(e,3);
    dof1 = (n1-1)*ndof+(1:ndof);
    dof2 = (n2-1)*ndof+(1:ndof);
    de = [d(dof1); d(dof2)];
    strain = ((de(3)-de(1))*c+(de(4)-de(2))*s)/L;
    stress = data.E(e)*strain;
    axial_force = stress*data.A(e);
    print_both(fid, '单元 %d: 长度=%.4f, c=%.4f, s=%.4f\n', e,L,c,s);
    print_both(fid, '        应变=%.6f, 应力=%.6f, 轴力=%.6f\n', ...
        strain,stress,axial_force);
end
print_both(fid, '\n========== 程序运行结束 ==========\n\n');
end

function print_both(fid, formatSpec, varargin)
% 同时输出到 MATLAB 命令窗口和文本文件
fprintf(formatSpec, varargin{:});
fprintf(fid, formatSpec, varargin{:});
end

function print_matrix(fid, M, fmt)
% 按统一格式同时打印矩阵
for i = 1:size(M,1)
    for j = 1:size(M,2)
        fprintf(fmt, M(i,j));
        fprintf(fid, fmt, M(i,j));
    end
    fprintf('\n'); fprintf(fid,'\n');
end
end
