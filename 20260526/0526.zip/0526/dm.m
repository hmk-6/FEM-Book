% ========================================================================
% 三维杆单元（空间桁架单元）计算程序
% 姓名：韩梦坤    学号：20252210045
% 功能：计算单元长度、方向余弦、刚度矩阵、应变、应力、轴力
% 说明：一次运行完成两个算例，并将命令窗口结果保存为 anli.txt
% MATLAB 版本：R2024a
% ========================================================================

clear; clc;
format short;

% 保存运行结果到文本文件
if exist('anli.txt', 'file')
    delete('anli.txt');
end
diary('anli.txt');
diary on;

%% 算例一：沿全局 x 轴布置的杆单元
fprintf('==================== 算例一 ====================\n');
node1 = [0, 0, 0];
node2 = [2, 0, 0];
E = 2.0e11;                 % 弹性模量 (Pa)
A = 1.0e-4;                 % 横截面积 (m^2)
de = [0; 0; 0; 1.0e-3; 0; 0];

[Ke1, strain1, stress1, axial_force1, L1, c1] = ...
    TrussElement(node1, node2, E, A, de);
PrintResult(L1, c1, Ke1, strain1, stress1, axial_force1);

%% 算例二：任意空间方向杆单元
fprintf('\n==================== 算例二 ====================\n');
node1 = [0, 0, 0];
node2 = [2, 2, 1];
E = 2.1e11;                 % 弹性模量 (Pa)
A = 2.0e-4;                 % 横截面积 (m^2)
de = [0; 0; 0; 2.0e-3; 2.0e-3; 1.0e-3];

[Ke2, strain2, stress2, axial_force2, L2, c2] = ...
    TrussElement(node1, node2, E, A, de);
PrintResult(L2, c2, Ke2, strain2, stress2, axial_force2);

%% 刚度矩阵物理意义验证（以算例二为例）
d_unit = [1; 0; 0; 0; 0; 0];
Fe = Ke2 * d_unit;
fprintf('\n算例二刚度矩阵第 1 列验证：\n');
fprintf('令 d = [1, 0, 0, 0, 0, 0]^T，则 Fe = Ke*d：\n');
disp(Fe);

fprintf('计算完成，结果已保存到 anli.txt。\n');
diary off;

% ========================================================================
% 三维杆单元计算函数
% ========================================================================
function [Ke, strain, stress, axial_force, L, c] = ...
    TrussElement(node1, node2, E, A, de)

    % 计算单元长度及方向余弦
    delta = node2 - node1;
    L = norm(delta);
    if L <= eps
        error('两个节点不能重合，单元长度必须大于 0。');
    end
    c = delta(:) / L;
    cx = c(1); cy = c(2); cz = c(3);

    % 应变-位移矩阵 B (1x6)
    B = (1/L) * [-cx, -cy, -cz, cx, cy, cz];

    % 全局坐标系下的单元刚度矩阵 (6x6)
    k0 = E * A / L;
    ccT = c * c';
    Ke = k0 * [ ccT, -ccT;
               -ccT,  ccT ];

    % 应变、应力及轴力
    strain = B * de;
    stress = E * strain;
    axial_force = stress * A;
end

% ========================================================================
% 结果输出函数
% ========================================================================
function PrintResult(L, c, Ke, strain, stress, axial_force)
    fprintf('单元长度 L = %.4f m\n', L);
    fprintf('方向余弦: (cx, cy, cz) = (%.4f, %.4f, %.4f)\n', ...
        c(1), c(2), c(3));
    fprintf('单元刚度矩阵 Ke (6x6):\n');
    disp(Ke);
    fprintf('单元应变 epsilon = %.6e\n', strain);
    fprintf('单元应力 sigma = %.2f Pa\n', stress);
    fprintf('单元轴力 N = %.2f N\n', axial_force);
end
